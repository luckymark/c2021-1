#include<cstdio>
#include<stdlib.h>
#include<conio.h>
#include<fstream>
#include<iostream>
#define maxn 105
using namespace std;

char mp[maxn][maxn];
int dis[15][2];
int tot=0,aim=0,fl=0,nw=0,src=100,restart=0;

int check(int x,int y)
{
	if(mp[x][y]=='*'||mp[x][y]=='$')return 0;
	else return 1;
}

int checkk(int x,int y)
{
	for(int i=1;i<=nw;++i)
	{
		if(dis[i][0]==x&&dis[i][1]==y)
		return 1;
	}
	return 0;
}

void print(int op,int x,int y)
{
	system("cls");
	printf("��%d��:\n",op);
	for(int i=0;i<=x;++i)
	{
		for(int j=0;j<=y;++j)
		{
			printf("%c",mp[i][j]);
		}
		printf("\n");
	}
	printf("a:����,w:����,s:����,d:����,o:�ؿ�\n");
	printf("��ɸ���:%d\n",tot);
	printf("���ĵ÷�:%d\n",src);
}

void change(int opx,int opy,int &x,int &y,int xx,int yy)
{
	if(checkk(x,y)&&check(xx,yy))
	mp[x][y]='@';
	if(mp[xx][yy]=='$')//������
	{
		int xxx=xx+opx;
		int yyy=yy+opy;
		if(check(xxx,yyy))
		{
			if(mp[xxx][yyy]=='@')
			{
				src+=50;
				tot++;
			}
			mp[xxx][yyy]='$';
			mp[xx][yy]='&';
			if(!checkk(x,y))
			mp[x][y]=' ';
			else mp[x][y]='@';
			x=xx;y=yy;
		}
		if(checkk(xx,yy)&&check(xx,yy))
		{
			tot--;
			src-=50;
		}
	}
	else
	{
		if(check(xx,yy))
		{
			mp[xx][yy]='&';
			if(!checkk(x,y))
			mp[x][y]=' ';
			else mp[x][y]='@';
			x=xx;y=yy;
		}
	}
	if(tot==aim)
	fl=1;
}

void read(int &x,int &y)
{
	src--;
	int xx,yy;
	char op;
	op=getch();
	while(op!='w'&&op!='a'&&op!='s'&&op!='d'&&op!='o')
	op=getch();
	switch (op)
	{
		case 'w':
		{
			xx=x-1;yy=y;
			change(-1,0,x,y,xx,yy);
			break;
		}
		case 'a':
		{
			xx=x;yy=y-1;
			change(0,-1,x,y,xx,yy);
			break;
		}
		case 's':
		{
			xx=x+1;yy=y;
			change(1,0,x,y,xx,yy);
			break;
		}
		case 'd':
		{
			xx=x;yy=y+1;
			change(0,1,x,y,xx,yy);
			break;
		}
		case 'o':
		{
			restart=1;
			break;
		}
	}
}

void chapter1()
{
	do
	{	
		tot=0;aim=1;fl=0;nw=0;restart=0;
		int x=1,y=1;
		ifstream infile;
		infile.open("mp1.txt",ios::in);
		for(int i=0;i<=6;++i)
		{
			for(int j=0;j<=8;++j)
			{
				infile>>noskipws>>mp[i][j];
				if(mp[i][j]=='@')
				{
					nw++;
					dis[nw][0]=i;
					dis[nw][1]=j;
				}
			}
		}
		infile.close();
		print(1,6,7);
		while(!fl&&!restart)
		{
			read(x,y);
			print(1,6,7);
		}
		if(restart)
		src-=tot*50;
	}
	while(restart);
	ofstream outfile;
	outfile.open("scores.txt",ios::out);
	outfile<<"��һ�ص÷�:"<<src<<endl;
	outfile.close();
}

void chapter2()
{
	do
	{
		tot=0;aim=4;fl=0;nw=0;restart=0;
		int x=4,y=4;
		ifstream infile;
		infile.open("mp2.txt",ios::in);
		for(int i=0;i<=7;++i)
		{	
			for(int j=0;j<=8;++j)
			{
				infile>>noskipws>>mp[i][j];
				if(mp[i][j]=='@')
				{
					nw++;
					dis[nw][0]=i;
					dis[nw][1]=j;
				}
			}
		}
		infile.close();
		print(2,7,7);
		while(!fl&&!restart)
		{
			read(x,y);
			print(2,7,7);
		}
		if(restart)
		src-=tot*50;
	}
	while(restart);
	ofstream outfile;
	outfile.open("scores.txt",ios::app);
	outfile<<"�ڶ��ص÷�:"<<src<<endl;
	outfile.close();
}

void chapter3()
{
	do
	{
		tot=0;aim=3;fl=0;nw=0;restart=0;
		int x=1,y=1;
		ifstream infile;
		infile.open("mp3.txt",ios::in);
		for(int i=0;i<=9;++i)
		{
			for(int j=0;j<=9;++j)
			{
				infile>>noskipws>>mp[i][j];
				if(mp[i][j]=='@')
				{
					nw++;
					dis[nw][0]=i;
					dis[nw][1]=j;
				}
			}
		}
		infile.close();
		print(3,9,8);
		while(!fl&&!restart)
		{
			read(x,y);
			print(3,9,8);
		}
		if(restart)
		src-=tot*50;
	}
	while(restart);
	ofstream outfile;
	outfile.open("scores.txt",ios::app);
	outfile<<"�����ص÷�:"<<src<<endl;
	outfile.close();
}

void chapter4()
{
	do
	{
		tot=0;aim=4;fl=0;nw=0;restart=0;
		int x=8,y=11;
		ifstream infile;
		infile.open("mp4.txt",ios::in);
		for(int i=0;i<=10;++i)
		{
			for(int j=0;j<=13;++j)
			{
				infile>>noskipws>>mp[i][j];
				if(mp[i][j]=='@')
				{
					nw++;
					dis[nw][0]=i;
					dis[nw][1]=j;
				}
			}
		}
		infile.close();
		print(4,10,12);
		while(!fl&&!restart)
		{
			read(x,y);
			print(4,10,12);
		}
		if(restart)
		src-=tot*50;
	}
	while(restart);
	ofstream outfile;
	outfile.open("scores.txt",ios::app);
	outfile<<"���Ĺص÷�:"<<src<<endl;
	outfile.close();
}

void chapter5()
{
	do
	{
		tot=0;aim=10;fl=0;nw=0;restart=0;
		int x=1,y=1;
		ifstream infile;
		infile.open("mp5.txt",ios::in);
		for(int i=0;i<=14;++i)
		{
			for(int j=0;j<=15;++j)
			{
				infile>>noskipws>>mp[i][j];
				if(mp[i][j]=='@')
				{
					nw++;
					dis[nw][0]=i;
					dis[nw][1]=j;
				}
			}
		}
		infile.close();
		print(5,14,14);
		while(!fl&&!restart)
		{
			read(x,y);
			print(5,14,14);
		}
		if(restart)
		src-=tot*50;
	}
	while(restart);
	ofstream outfile;
	outfile.open("scores.txt",ios::app);
	outfile<<"����ص÷�:"<<src<<endl;
	outfile.close();
}

int main()
{
	chapter1();
	chapter2();
	chapter3();
	chapter4();
	chapter5();
	system("cls");
	printf("��ϲͨ�أ�\n�ܷ�:%d",src);
	return 0;
}
/*
��һ��
********
*& *   *
* $    *
*      *
*      *
*  *  @*
********
�ڶ���
  ***
  *@*
  * ****
***$ $@*
*@ $&***
****$*
   *@*
   ***  
������
*****
*&  *
* $$* ***
* $ * *@*
*** ***@*
 **    @*
 *      *
 *   *  *
 *   ****
 *****   
���Ĺ�
   *******
****     *
*   @*** *
* * *    **
* * $ $*@ *
* *     * *
* @*$ $ * *
**    * * ***
 * ***@    &*
 *          *
 ************
�����
******    *****
*&   ******   *
*  $       $  *
** * *  ***   *
 *  $       $**
 *$ ** * $ $ *
** $  $*     *
*   *        *
*   *****$****
*****       *
    *@@@  $ *
    *@@@    *
    *@@@@****
    ******     
*/